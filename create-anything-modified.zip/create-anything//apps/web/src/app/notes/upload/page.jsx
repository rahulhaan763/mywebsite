import { useState } from "react";
import useUser from "@/utils/useUser";
import useUpload from "@/utils/useUpload";
import { BookOpen, Upload, FileText, Image, FileIcon, X, CheckCircle } from "lucide-react";

function MainComponent() {
  const { data: user, loading: userLoading } = useUser();
  const [title, setTitle] = useState("");
  const [subject, setSubject] = useState("");
  const [classLevel, setClassLevel] = useState("");
  const [originalContent, setOriginalContent] = useState("");
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);

  const { uploadFile, uploading: fileUploading } = useUpload();

  const subjects = [
    "Mathematics", "Physics", "Chemistry", "Biology", "English", 
    "History", "Geography", "Economics", "Political Science", 
    "Computer Science", "Hindi", "Other"
  ];

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      // Check file size (max 10MB)
      if (selectedFile.size > 10 * 1024 * 1024) {
        setError("File size must be less than 10MB");
        return;
      }
      
      // Check file type
      const allowedTypes = [
        'application/pdf',
        'image/jpeg',
        'image/png',
        'image/jpg',
        'text/plain',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
      ];
      
      if (!allowedTypes.includes(selectedFile.type)) {
        setError("Please upload PDF, image, text, or Word documents only");
        return;
      }
      
      setFile(selectedFile);
      setError(null);
    }
  };

  const removeFile = () => {
    setFile(null);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setUploading(true);
    setError(null);

    try {
      if (!title || !subject || !classLevel) {
        throw new Error("Please fill in all required fields");
      }

      let fileUrl = null;
      let fileType = null;

      // Upload file if present
      if (file) {
        const uploadResult = await uploadFile(file);
        fileUrl = uploadResult.url;
        fileType = file.type;
      }

      // Create note
      const response = await fetch("/api/notes", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          title,
          subject,
          class_level: parseInt(classLevel),
          original_content: originalContent || null,
          file_url: fileUrl,
          file_type: fileType,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to upload note");
      }

      const result = await response.json();
      
      setSuccess(true);
      setTitle("");
      setSubject("");
      setClassLevel("");
      setOriginalContent("");
      setFile(null);

      // Show success message for 3 seconds then redirect
      setTimeout(() => {
        window.location.href = "/dashboard";
      }, 3000);

    } catch (err) {
      console.error("Upload error:", err);
      setError(err.message);
    } finally {
      setUploading(false);
    }
  };

  if (userLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-sky-50 via-blue-50 to-indigo-100 font-nunito flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#1E90FF] mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-sky-50 via-blue-50 to-indigo-100 font-nunito flex items-center justify-center">
        <div className="text-center">
          <BookOpen size={48} className="mx-auto text-[#1E90FF] mb-4" />
          <h2 className="text-2xl font-bold text-gray-800 mb-4">Please Sign In</h2>
          <p className="text-gray-600 mb-6">You need to be signed in to upload notes.</p>
          <a href="/account/signin" className="bg-[#1E90FF] text-white px-6 py-3 rounded-lg hover:bg-[#0066CC] transition-colors">
            Sign In
          </a>
        </div>
      </div>
    );
  }

  if (success) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-sky-50 via-blue-50 to-indigo-100 font-nunito flex items-center justify-center">
        <div className="bg-white rounded-2xl shadow-xl p-8 w-full max-w-md text-center">
          <CheckCircle size={64} className="mx-auto text-green-500 mb-4" />
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Note Uploaded Successfully!</h2>
          <p className="text-gray-600 mb-4">You earned 10 points! 🎉</p>
          <p className="text-sm text-gray-500">Redirecting to dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 via-blue-50 to-indigo-100 font-nunito">
      {/* Navigation */}
      <nav className="bg-white/80 backdrop-blur-md shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <a href="/dashboard" className="flex items-center">
                <BookOpen size={32} className="text-[#1E90FF] mr-2" />
                <span className="text-2xl font-bold text-gray-800">EDUSNAP</span>
              </a>
            </div>
            <div className="flex items-center space-x-6">
              <a href="/dashboard" className="text-gray-600 hover:text-[#1E90FF] transition-colors">Dashboard</a>
              <a href="/notes" className="text-gray-600 hover:text-[#1E90FF] transition-colors">My Notes</a>
              <div className="flex items-center space-x-2">
                <img 
                  src={user.image || `https://ui-avatars.com/api/?name=${encodeURIComponent(user.name)}&background=1E90FF&color=fff`}
                  alt={user.name}
                  className="w-8 h-8 rounded-full"
                />
                <span className="text-gray-700 font-medium">{user.name}</span>
              </div>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-800 mb-2">Upload Notes</h1>
          <p className="text-gray-600">Share your study materials and earn points! 📚</p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Title */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Note Title *
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g., Algebra Basics, Cell Biology, World War II"
                className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#1E90FF] focus:border-transparent outline-none transition-all"
                required
              />
            </div>

            {/* Subject and Class Level */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Subject *
                </label>
                <select
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#1E90FF] focus:border-transparent outline-none transition-all"
                  required
                >
                  <option value="">Select subject</option>
                  {subjects.map(sub => (
                    <option key={sub} value={sub}>{sub}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Class Level *
                </label>
                <select
                  value={classLevel}
                  onChange={(e) => setClassLevel(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#1E90FF] focus:border-transparent outline-none transition-all"
                  required
                >
                  <option value="">Select class</option>
                  <option value="8">Class 8th</option>
                  <option value="9">Class 9th</option>
                  <option value="10">Class 10th</option>
                  <option value="11">Class 11th</option>
                  <option value="12">Class 12th</option>
                </select>
              </div>
            </div>

            {/* File Upload */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Upload File (Optional)
              </label>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-[#1E90FF] transition-colors">
                {file ? (
                  <div className="flex items-center justify-between bg-gray-50 rounded-lg p-4">
                    <div className="flex items-center space-x-3">
                      {file.type.includes('image') ? (
                        <Image size={24} className="text-green-500" />
                      ) : file.type.includes('pdf') ? (
                        <FileText size={24} className="text-red-500" />
                      ) : (
                        <FileIcon size={24} className="text-blue-500" />
                      )}
                      <div className="text-left">
                        <p className="font-medium text-gray-800">{file.name}</p>
                        <p className="text-sm text-gray-500">{(file.size / 1024 / 1024).toFixed(2)} MB</p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={removeFile}
                      className="text-gray-400 hover:text-red-500 transition-colors"
                    >
                      <X size={20} />
                    </button>
                  </div>
                ) : (
                  <>
                    <Upload size={48} className="mx-auto text-gray-400 mb-4" />
                    <p className="text-gray-600 mb-2">
                      Drop your file here or click to browse
                    </p>
                    <p className="text-sm text-gray-500">
                      PDF, images, text files up to 10MB
                    </p>
                    <input
                      type="file"
                      onChange={handleFileChange}
                      className="hidden"
                      id="file-upload"
                      accept=".pdf,.jpg,.jpeg,.png,.txt,.doc,.docx"
                    />
                    <label
                      htmlFor="file-upload"
                      className="mt-4 inline-block bg-[#1E90FF] text-white px-6 py-2 rounded-lg cursor-pointer hover:bg-[#0066CC] transition-colors"
                    >
                      Choose File
                    </label>
                  </>
                )}
              </div>
            </div>

            {/* Content */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Note Content (Optional)
              </label>
              <textarea
                value={originalContent}
                onChange={(e) => setOriginalContent(e.target.value)}
                placeholder="Type or paste your notes here..."
                rows={8}
                className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#1E90FF] focus:border-transparent outline-none transition-all resize-vertical"
              />
              <p className="text-sm text-gray-500 mt-2">
                You can add content here even without uploading a file
              </p>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-600">
                {error}
              </div>
            )}

            {/* Submit Button */}
            <div className="flex items-center justify-between pt-6">
              <a
                href="/dashboard"
                className="text-gray-600 hover:text-gray-800 transition-colors"
              >
                ← Back to Dashboard
              </a>
              <button
                type="submit"
                disabled={uploading || fileUploading}
                className="bg-[#1E90FF] text-white px-8 py-3 rounded-lg font-medium hover:bg-[#0066CC] focus:ring-2 focus:ring-[#1E90FF] focus:ring-offset-2 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {uploading || fileUploading ? "Uploading..." : "Upload Note (+10 points)"}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;