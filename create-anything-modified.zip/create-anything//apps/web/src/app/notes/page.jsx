import { useState, useEffect } from "react";
import useUser from "@/utils/useUser";
import { BookOpen, FileText, Plus, Search, Filter, Calendar, Eye, Download } from "lucide-react";

function MainComponent() {
  const { data: user, loading: userLoading } = useUser();
  const [notes, setNotes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedSubject, setSelectedSubject] = useState("");
  const [selectedClass, setSelectedClass] = useState("");

  const subjects = [
    "Mathematics", "Physics", "Chemistry", "Biology", "English", 
    "History", "Geography", "Economics", "Political Science", 
    "Computer Science", "Hindi", "Other"
  ];

  useEffect(() => {
    if (user) {
      fetchNotes();
    }
  }, [user, selectedSubject, selectedClass]);

  const fetchNotes = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      if (selectedSubject) params.append('subject', selectedSubject);
      if (selectedClass) params.append('class', selectedClass);
      
      const response = await fetch(`/api/notes?${params.toString()}`);
      if (!response.ok) {
        throw new Error("Failed to fetch notes");
      }
      
      const data = await response.json();
      setNotes(data.notes || []);
    } catch (err) {
      console.error("Error fetching notes:", err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  // Filter notes based on search term
  const filteredNotes = notes.filter(note =>
    note.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    note.subject.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (userLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-sky-50 via-blue-50 to-indigo-100 font-nunito flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#1E90FF] mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-sky-50 via-blue-50 to-indigo-100 font-nunito flex items-center justify-center">
        <div className="text-center">
          <BookOpen size={48} className="mx-auto text-[#1E90FF] mb-4" />
          <h2 className="text-2xl font-bold text-gray-800 mb-4">Please Sign In</h2>
          <p className="text-gray-600 mb-6">You need to be signed in to view your notes.</p>
          <a href="/account/signin" className="bg-[#1E90FF] text-white px-6 py-3 rounded-lg hover:bg-[#0066CC] transition-colors">
            Sign In
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 via-blue-50 to-indigo-100 font-nunito">
      {/* Navigation */}
      <nav className="bg-white/80 backdrop-blur-md shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <a href="/dashboard" className="flex items-center">
                <BookOpen size={32} className="text-[#1E90FF] mr-2" />
                <span className="text-2xl font-bold text-gray-800">EDUSNAP</span>
              </a>
            </div>
            <div className="flex items-center space-x-6">
              <a href="/dashboard" className="text-gray-600 hover:text-[#1E90FF] transition-colors">Dashboard</a>
              <a href="/notes" className="text-[#1E90FF] font-medium">My Notes</a>
              <div className="flex items-center space-x-2">
                <img 
                  src={user.image || `https://ui-avatars.com/api/?name=${encodeURIComponent(user.name)}&background=1E90FF&color=fff`}
                  alt={user.name}
                  className="w-8 h-8 rounded-full"
                />
                <span className="text-gray-700 font-medium">{user.name}</span>
              </div>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-800 mb-2">My Notes</h1>
            <p className="text-gray-600">Manage your study materials</p>
          </div>
          <a
            href="/notes/upload"
            className="bg-[#1E90FF] text-white px-6 py-3 rounded-lg hover:bg-[#0066CC] transition-colors flex items-center space-x-2"
          >
            <Plus size={20} />
            <span>Upload Note</span>
          </a>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-2xl shadow-sm p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {/* Search */}
            <div className="md:col-span-2">
              <div className="relative">
                <Search size={20} className="absolute left-3 top-3 text-gray-400" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search notes..."
                  className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#1E90FF] focus:border-transparent outline-none transition-all"
                />
              </div>
            </div>

            {/* Subject Filter */}
            <div>
              <select
                value={selectedSubject}
                onChange={(e) => setSelectedSubject(e.target.value)}
                className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#1E90FF] focus:border-transparent outline-none transition-all"
              >
                <option value="">All Subjects</option>
                {subjects.map(subject => (
                  <option key={subject} value={subject}>{subject}</option>
                ))}
              </select>
            </div>

            {/* Class Filter */}
            <div>
              <select
                value={selectedClass}
                onChange={(e) => setSelectedClass(e.target.value)}
                className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#1E90FF] focus:border-transparent outline-none transition-all"
              >
                <option value="">All Classes</option>
                <option value="8">Class 8th</option>
                <option value="9">Class 9th</option>
                <option value="10">Class 10th</option>
                <option value="11">Class 11th</option>
                <option value="12">Class 12th</option>
              </select>
            </div>
          </div>
        </div>

        {/* Notes Grid */}
        {loading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#1E90FF] mx-auto mb-4"></div>
            <p className="text-gray-600">Loading your notes...</p>
          </div>
        ) : error ? (
          <div className="bg-red-50 border border-red-200 rounded-lg p-6 text-center">
            <p className="text-red-600">{error}</p>
            <button 
              onClick={fetchNotes}
              className="mt-4 bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors"
            >
              Try Again
            </button>
          </div>
        ) : filteredNotes.length === 0 ? (
          <div className="text-center py-12">
            <FileText size={64} className="mx-auto text-gray-300 mb-4" />
            <h3 className="text-xl font-bold text-gray-800 mb-2">No Notes Found</h3>
            <p className="text-gray-600 mb-6">
              {searchTerm || selectedSubject || selectedClass 
                ? "No notes match your search criteria"
                : "You haven't uploaded any notes yet"
              }
            </p>
            <a
              href="/notes/upload"
              className="bg-[#1E90FF] text-white px-6 py-3 rounded-lg hover:bg-[#0066CC] transition-colors inline-flex items-center space-x-2"
            >
              <Plus size={20} />
              <span>Upload Your First Note</span>
            </a>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredNotes.map((note) => (
              <div key={note.id} className="bg-white rounded-2xl shadow-sm hover:shadow-md transition-shadow p-6">
                {/* Note Header */}
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h3 className="font-bold text-gray-800 mb-1 line-clamp-2">{note.title}</h3>
                    <div className="flex items-center space-x-2 text-sm text-gray-600">
                      <span className="bg-blue-100 text-blue-700 px-2 py-1 rounded-full text-xs">
                        {note.subject}
                      </span>
                      <span className="bg-gray-100 text-gray-700 px-2 py-1 rounded-full text-xs">
                        Class {note.class_level}
                      </span>
                    </div>
                  </div>
                  <FileText size={24} className="text-gray-400 flex-shrink-0 ml-2" />
                </div>

                {/* File Info */}
                {note.file_url && (
                  <div className="bg-gray-50 rounded-lg p-3 mb-4">
                    <div className="flex items-center space-x-2 text-sm text-gray-600">
                      <FileText size={16} />
                      <span>File attached</span>
                      <span className="text-xs bg-gray-200 px-2 py-1 rounded">
                        {note.file_type?.split('/')[1]?.toUpperCase() || 'FILE'}
                      </span>
                    </div>
                  </div>
                )}

                {/* Date */}
                <div className="flex items-center text-xs text-gray-500 mb-4">
                  <Calendar size={14} className="mr-1" />
                  <span>{new Date(note.created_at).toLocaleDateString()}</span>
                </div>

                {/* Actions */}
                <div className="flex items-center justify-between">
                  <a
                    href={`/notes/${note.id}`}
                    className="text-[#1E90FF] hover:text-[#0066CC] font-medium text-sm flex items-center space-x-1"
                  >
                    <Eye size={16} />
                    <span>View</span>
                  </a>
                  
                  {note.file_url && (
                    <a
                      href={note.file_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-gray-600 hover:text-gray-800 text-sm flex items-center space-x-1"
                    >
                      <Download size={16} />
                      <span>Download</span>
                    </a>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Stats Summary */}
        {filteredNotes.length > 0 && (
          <div className="mt-8 bg-white rounded-2xl shadow-sm p-6">
            <h3 className="text-lg font-bold text-gray-800 mb-4">Summary</h3>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-center">
              <div>
                <p className="text-2xl font-bold text-[#1E90FF]">{filteredNotes.length}</p>
                <p className="text-sm text-gray-600">Total Notes</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-green-600">
                  {new Set(filteredNotes.map(n => n.subject)).size}
                </p>
                <p className="text-sm text-gray-600">Subjects</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-purple-600">
                  {new Set(filteredNotes.map(n => n.class_level)).size}
                </p>
                <p className="text-sm text-gray-600">Class Levels</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-orange-600">
                  {filteredNotes.filter(n => n.file_url).length}
                </p>
                <p className="text-sm text-gray-600">With Files</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default MainComponent;