import { BookOpen, Brain, FileText, Map, Trophy, Users, ArrowRight, Star, Zap, Target } from "lucide-react";

function MainComponent() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 via-blue-50 to-indigo-100 font-nunito">
      {/* Navigation */}
      <nav className="bg-white/80 backdrop-blur-md shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <BookOpen size={32} className="text-[#1E90FF] mr-2" />
              <span className="text-2xl font-bold text-gray-800">EDUSNAP</span>
            </div>
            <div className="hidden md:flex items-center space-x-8">
              <a href="#features" className="text-gray-600 hover:text-[#1E90FF] transition-colors">Features</a>
              <a href="#subjects" className="text-gray-600 hover:text-[#1E90FF] transition-colors">Subjects</a>
              <a href="#how-it-works" className="text-gray-600 hover:text-[#1E90FF] transition-colors">How it Works</a>
              <a href="/account/signin" className="text-[#1E90FF] hover:text-[#0066CC] font-medium">Sign In</a>
              <a href="/account/signup" className="bg-[#1E90FF] text-white px-4 py-2 rounded-lg hover:bg-[#0066CC] transition-colors">
                Get Started
              </a>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-gray-800 mb-6">
              Convert Notes into
              <span className="text-[#1E90FF] block">Smart Summaries, Mind Maps & Quizzes</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              Transform your study experience with AI-powered tools. Upload your notes and get instant summaries, 
              visual mind maps, and interactive quizzes. Perfect for students from Class 8th to 12th.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a href="/account/signup" className="bg-[#1E90FF] text-white px-8 py-4 rounded-lg text-lg font-medium hover:bg-[#0066CC] transition-colors inline-flex items-center">
                Start Learning Free
                <ArrowRight className="ml-2" size={20} />
              </a>
              <a href="#features" className="border-2 border-[#1E90FF] text-[#1E90FF] px-8 py-4 rounded-lg text-lg font-medium hover:bg-[#1E90FF] hover:text-white transition-colors">
                See How It Works
              </a>
            </div>
          </div>

          {/* Stats */}
          <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="text-3xl font-bold text-[#1E90FF] mb-2">10x</div>
              <div className="text-gray-600">Faster Learning</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-[#1E90FF] mb-2">5+</div>
              <div className="text-gray-600">Study Tools</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-[#1E90FF] mb-2">100%</div>
              <div className="text-gray-600">AI-Powered</div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
              Powerful Features for Smart Learning
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Everything you need to transform your study habits and boost your academic performance
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Notes Summarizer */}
            <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-8 rounded-2xl">
              <FileText className="text-[#1E90FF] mb-4" size={48} />
              <h3 className="text-xl font-bold text-gray-800 mb-3">Notes Summarizer</h3>
              <p className="text-gray-600 mb-4">
                Upload lengthy notes in PDF, Word, or Text format and get AI-generated summaries instantly.
              </p>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Multiple file format support</li>
                <li>• Instant AI summarization</li>
                <li>• Download & save options</li>
              </ul>
            </div>

            {/* Mind Map Generator */}
            <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-8 rounded-2xl">
              <Map className="text-purple-600 mb-4" size={48} />
              <h3 className="text-xl font-bold text-gray-800 mb-3">Mind Map Generator</h3>
              <p className="text-gray-600 mb-4">
                Convert your notes into visual mind maps with clear nodes and branches for better understanding.
              </p>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Visual concept mapping</li>
                <li>• Interactive design</li>
                <li>• Export as image/PDF</li>
              </ul>
            </div>

            {/* Quiz Creator */}
            <div className="bg-gradient-to-br from-green-50 to-green-100 p-8 rounded-2xl">
              <Brain className="text-green-600 mb-4" size={48} />
              <h3 className="text-xl font-bold text-gray-800 mb-3">Quiz Creator</h3>
              <p className="text-gray-600 mb-4">
                Generate MCQs and quizzes automatically from your notes with detailed explanations.
              </p>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Auto-generated questions</li>
                <li>• Instant scoring</li>
                <li>• Detailed explanations</li>
              </ul>
            </div>

            {/* Numerical Solver */}
            <div className="bg-gradient-to-br from-orange-50 to-orange-100 p-8 rounded-2xl">
              <Target className="text-orange-600 mb-4" size={48} />
              <h3 className="text-xl font-bold text-gray-800 mb-3">Numerical Solver</h3>
              <p className="text-gray-600 mb-4">
                Get step-by-step solutions for math, physics, and chemistry problems.
              </p>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Step-by-step solutions</li>
                <li>• Multiple subjects</li>
                <li>• Clear explanations</li>
              </ul>
            </div>

            {/* Gamification */}
            <div className="bg-gradient-to-br from-yellow-50 to-yellow-100 p-8 rounded-2xl">
              <Trophy className="text-yellow-600 mb-4" size={48} />
              <h3 className="text-xl font-bold text-gray-800 mb-3">Gamification</h3>
              <p className="text-gray-600 mb-4">
                Earn points, unlock achievements, and compete on leaderboards while learning.
              </p>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Points & achievements</li>
                <li>• Leaderboards</li>
                <li>• Study streaks</li>
              </ul>
            </div>

            {/* Dashboard */}
            <div className="bg-gradient-to-br from-indigo-50 to-indigo-100 p-8 rounded-2xl">
              <Users className="text-indigo-600 mb-4" size={48} />
              <h3 className="text-xl font-bold text-gray-800 mb-3">Personal Dashboard</h3>
              <p className="text-gray-600 mb-4">
                Track your progress, manage notes, and view your learning analytics in one place.
              </p>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Progress tracking</li>
                <li>• Note management</li>
                <li>• Learning analytics</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Subjects Section */}
      <section id="subjects" className="py-20 bg-gradient-to-br from-sky-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
              All Subjects Covered
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              From Class 8th to 12th, we support all major subjects with specialized AI tools
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6">
            {[
              { name: "Mathematics", icon: "📊", color: "bg-blue-100 text-blue-600" },
              { name: "Physics", icon: "⚛️", color: "bg-purple-100 text-purple-600" },
              { name: "Chemistry", icon: "🧪", color: "bg-green-100 text-green-600" },
              { name: "Biology", icon: "🧬", color: "bg-red-100 text-red-600" },
              { name: "History", icon: "📜", color: "bg-yellow-100 text-yellow-600" },
              { name: "Geography", icon: "🌍", color: "bg-indigo-100 text-indigo-600" },
              { name: "English", icon: "📚", color: "bg-pink-100 text-pink-600" },
              { name: "Computer Science", icon: "💻", color: "bg-gray-100 text-gray-600" },
              { name: "Economics", icon: "💰", color: "bg-emerald-100 text-emerald-600" },
              { name: "Political Science", icon: "🏛️", color: "bg-orange-100 text-orange-600" },
              { name: "Psychology", icon: "🧠", color: "bg-teal-100 text-teal-600" },
              { name: "Sociology", icon: "👥", color: "bg-violet-100 text-violet-600" }
            ].map((subject, index) => (
              <div key={index} className={`${subject.color} p-6 rounded-2xl text-center hover:scale-105 transition-transform cursor-pointer`}>
                <div className="text-3xl mb-2">{subject.icon}</div>
                <div className="font-semibold text-sm">{subject.name}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
              How EDUSNAP Works
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Simple 3-step process to transform your learning experience
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-[#1E90FF] text-white w-16 h-16 rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-6">1</div>
              <h3 className="text-xl font-bold text-gray-800 mb-3">Upload Your Notes</h3>
              <p className="text-gray-600">
                Simply upload your study materials in PDF, Word, or text format. Our AI will process them instantly.
              </p>
            </div>
            <div className="text-center">
              <div className="bg-[#1E90FF] text-white w-16 h-16 rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-6">2</div>
              <h3 className="text-xl font-bold text-gray-800 mb-3">AI Processing</h3>
              <p className="text-gray-600">
                Our advanced AI analyzes your content and generates summaries, mind maps, and quiz questions.
              </p>
            </div>
            <div className="text-center">
              <div className="bg-[#1E90FF] text-white w-16 h-16 rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-6">3</div>
              <h3 className="text-xl font-bold text-gray-800 mb-3">Learn & Earn</h3>
              <p className="text-gray-600">
                Study with your personalized materials, take quizzes, and earn points while mastering concepts.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-[#1E90FF] to-[#0066CC]">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Ready to Transform Your Learning?
          </h2>
          <p className="text-xl text-blue-100 mb-8">
            Join thousands of students who are already learning smarter with EDUSNAP
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a href="/account/signup" className="bg-white text-[#1E90FF] px-8 py-4 rounded-lg text-lg font-medium hover:bg-gray-100 transition-colors inline-flex items-center">
              Get Started Free
              <ArrowRight className="ml-2" size={20} />
            </a>
            <a href="/account/signin" className="border-2 border-white text-white px-8 py-4 rounded-lg text-lg font-medium hover:bg-white hover:text-[#1E90FF] transition-colors">
              Sign In
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <BookOpen size={24} className="text-[#1E90FF] mr-2" />
                <span className="text-xl font-bold">EDUSNAP</span>
              </div>
              <p className="text-gray-400">
                Smart Study Simplified. Transform your learning with AI-powered tools.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Features</h3>
              <ul className="space-y-2 text-gray-400">
                <li>Notes Summarizer</li>
                <li>Mind Map Generator</li>
                <li>Quiz Creator</li>
                <li>Numerical Solver</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Subjects</h3>
              <ul className="space-y-2 text-gray-400">
                <li>Mathematics</li>
                <li>Science</li>
                <li>Social Studies</li>
                <li>Languages</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Support</h3>
              <ul className="space-y-2 text-gray-400">
                <li>Help Center</li>
                <li>Contact Us</li>
                <li>Privacy Policy</li>
                <li>Terms of Service</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 EDUSNAP. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default MainComponent;