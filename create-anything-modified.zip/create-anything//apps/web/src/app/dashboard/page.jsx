import { useState, useEffect } from "react";
import useUser from "@/utils/useUser";
import { 
  BookOpen, 
  Trophy, 
  Target, 
  FileText, 
  Map, 
  Brain, 
  Upload, 
  Star, 
  Flame, 
  Award,
  TrendingUp,
  Users,
  Calendar,
  Clock,
  Plus
} from "lucide-react";

function MainComponent() {
  const { data: user, loading: userLoading } = useUser();
  const [userProfile, setUserProfile] = useState(null);
  const [stats, setStats] = useState(null);
  const [achievements, setAchievements] = useState([]);
  const [leaderboard, setLeaderboard] = useState([]);
  const [recentNotes, setRecentNotes] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        // Fetch user profile
        const profileRes = await fetch("/api/users/profile");
        if (profileRes.ok) {
          const profileData = await profileRes.json();
          setUserProfile(profileData.user);
        }

        // Fetch user stats
        const statsRes = await fetch("/api/users/stats");
        if (statsRes.ok) {
          const statsData = await statsRes.json();
          setStats(statsData);
        }

        // Fetch achievements
        const achievementsRes = await fetch("/api/achievements");
        if (achievementsRes.ok) {
          const achievementsData = await achievementsRes.json();
          setAchievements(achievementsData.achievements || []);
        }

        // Fetch leaderboard
        const leaderboardRes = await fetch("/api/leaderboard");
        if (leaderboardRes.ok) {
          const leaderboardData = await leaderboardRes.json();
          setLeaderboard(leaderboardData.leaderboard || []);
        }

        // Fetch recent notes
        const notesRes = await fetch("/api/notes?limit=5");
        if (notesRes.ok) {
          const notesData = await notesRes.json();
          setRecentNotes(notesData.notes || []);
        }
      } catch (error) {
        console.error("Error fetching dashboard data:", error);
      } finally {
        setLoading(false);
      }
    };

    if (user) {
      fetchDashboardData();
    }
  }, [user]);

  if (userLoading || loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-sky-50 via-blue-50 to-indigo-100 font-nunito flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#1E90FF] mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-sky-50 via-blue-50 to-indigo-100 font-nunito flex items-center justify-center">
        <div className="text-center">
          <BookOpen size={48} className="mx-auto text-[#1E90FF] mb-4" />
          <h2 className="text-2xl font-bold text-gray-800 mb-4">Please Sign In</h2>
          <p className="text-gray-600 mb-6">You need to be signed in to access your dashboard.</p>
          <a href="/account/signin" className="bg-[#1E90FF] text-white px-6 py-3 rounded-lg hover:bg-[#0066CC] transition-colors">
            Sign In
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 via-blue-50 to-indigo-100 font-nunito">
      {/* Navigation */}
      <nav className="bg-white/80 backdrop-blur-md shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <BookOpen size={32} className="text-[#1E90FF] mr-2" />
              <span className="text-2xl font-bold text-gray-800">EDUSNAP</span>
            </div>
            <div className="flex items-center space-x-6">
              <a href="/notes" className="text-gray-600 hover:text-[#1E90FF] transition-colors">Notes</a>
              <a href="/quiz" className="text-gray-600 hover:text-[#1E90FF] transition-colors">Quiz</a>
              <a href="/leaderboard" className="text-gray-600 hover:text-[#1E90FF] transition-colors">Leaderboard</a>
              <div className="flex items-center space-x-2">
                <img 
                  src={user.image || `https://ui-avatars.com/api/?name=${encodeURIComponent(user.name)}&background=1E90FF&color=fff`}
                  alt={user.name}
                  className="w-8 h-8 rounded-full"
                />
                <span className="text-gray-700 font-medium">{user.name}</span>
              </div>
              <a href="/account/logout" className="text-gray-600 hover:text-red-600 transition-colors">
                Sign Out
              </a>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-800 mb-2">
            Welcome back, {user.name}! 👋
          </h1>
          <p className="text-gray-600">
            Ready to continue your learning journey? Let's make today productive!
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-2xl p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">Total Points</p>
                <p className="text-2xl font-bold text-[#1E90FF]">{userProfile?.total_points || 0}</p>
              </div>
              <Trophy className="text-yellow-500" size={32} />
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">Study Streak</p>
                <p className="text-2xl font-bold text-orange-500">{userProfile?.streak_days || 0} days</p>
              </div>
              <Flame className="text-orange-500" size={32} />
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">Notes Uploaded</p>
                <p className="text-2xl font-bold text-green-500">{stats?.total_notes || 0}</p>
              </div>
              <FileText className="text-green-500" size={32} />
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">Quizzes Taken</p>
                <p className="text-2xl font-bold text-purple-500">{stats?.total_quizzes || 0}</p>
              </div>
              <Brain className="text-purple-500" size={32} />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Quick Actions */}
            <div className="bg-white rounded-2xl p-6 shadow-sm">
              <h2 className="text-xl font-bold text-gray-800 mb-6">Quick Actions</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <a href="/notes/upload" className="bg-gradient-to-br from-blue-50 to-blue-100 p-6 rounded-xl hover:scale-105 transition-transform">
                  <Upload className="text-[#1E90FF] mb-3" size={32} />
                  <h3 className="font-semibold text-gray-800 mb-1">Upload Notes</h3>
                  <p className="text-sm text-gray-600">Add new study materials</p>
                </a>

                <a href="/quiz/create" className="bg-gradient-to-br from-green-50 to-green-100 p-6 rounded-xl hover:scale-105 transition-transform">
                  <Brain className="text-green-600 mb-3" size={32} />
                  <h3 className="font-semibold text-gray-800 mb-1">Take Quiz</h3>
                  <p className="text-sm text-gray-600">Test your knowledge</p>
                </a>

                <a href="/mindmap/create" className="bg-gradient-to-br from-purple-50 to-purple-100 p-6 rounded-xl hover:scale-105 transition-transform">
                  <Map className="text-purple-600 mb-3" size={32} />
                  <h3 className="font-semibold text-gray-800 mb-1">Mind Map</h3>
                  <p className="text-sm text-gray-600">Visualize concepts</p>
                </a>
              </div>
            </div>

            {/* Recent Notes */}
            <div className="bg-white rounded-2xl p-6 shadow-sm">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-gray-800">Recent Notes</h2>
                <a href="/notes" className="text-[#1E90FF] hover:text-[#0066CC] font-medium">View All</a>
              </div>
              
              {recentNotes.length > 0 ? (
                <div className="space-y-4">
                  {recentNotes.map((note) => (
                    <div key={note.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <FileText className="text-gray-400" size={20} />
                        <div>
                          <h3 className="font-medium text-gray-800">{note.title}</h3>
                          <p className="text-sm text-gray-600">{note.subject} • Class {note.class_level}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className="text-xs text-gray-500">
                          {new Date(note.created_at).toLocaleDateString()}
                        </span>
                        <a href={`/notes/${note.id}`} className="text-[#1E90FF] hover:text-[#0066CC]">
                          View
                        </a>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <FileText className="mx-auto text-gray-300 mb-4" size={48} />
                  <p className="text-gray-600 mb-4">No notes uploaded yet</p>
                  <a href="/notes/upload" className="bg-[#1E90FF] text-white px-4 py-2 rounded-lg hover:bg-[#0066CC] transition-colors">
                    Upload Your First Note
                  </a>
                </div>
              )}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-8">
            {/* Achievements */}
            <div className="bg-white rounded-2xl p-6 shadow-sm">
              <h2 className="text-xl font-bold text-gray-800 mb-6">Achievements</h2>
              
              {achievements.length > 0 ? (
                <div className="space-y-3">
                  {achievements.slice(0, 5).map((achievement) => (
                    <div key={achievement.id} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                      <div className="text-2xl">{achievement.icon}</div>
                      <div className="flex-1">
                        <h3 className="font-medium text-gray-800 text-sm">{achievement.name}</h3>
                        <p className="text-xs text-gray-600">{achievement.description}</p>
                      </div>
                      {achievement.earned ? (
                        <Award className="text-yellow-500" size={16} />
                      ) : (
                        <div className="w-4 h-4 border-2 border-gray-300 rounded-full"></div>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-4">
                  <Trophy className="mx-auto text-gray-300 mb-2" size={32} />
                  <p className="text-gray-600 text-sm">Start learning to unlock achievements!</p>
                </div>
              )}
            </div>

            {/* Leaderboard Preview */}
            <div className="bg-white rounded-2xl p-6 shadow-sm">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-gray-800">Leaderboard</h2>
                <a href="/leaderboard" className="text-[#1E90FF] hover:text-[#0066CC] font-medium">View All</a>
              </div>
              
              {leaderboard.length > 0 ? (
                <div className="space-y-3">
                  {leaderboard.slice(0, 5).map((student, index) => (
                    <div key={student.id} className="flex items-center space-x-3">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                        index === 0 ? 'bg-yellow-100 text-yellow-600' :
                        index === 1 ? 'bg-gray-100 text-gray-600' :
                        index === 2 ? 'bg-orange-100 text-orange-600' :
                        'bg-blue-50 text-blue-600'
                      }`}>
                        {index + 1}
                      </div>
                      <img 
                        src={student.profile_image || `https://ui-avatars.com/api/?name=${encodeURIComponent(student.name)}&background=1E90FF&color=fff`}
                        alt={student.name}
                        className="w-8 h-8 rounded-full"
                      />
                      <div className="flex-1">
                        <p className="font-medium text-gray-800 text-sm">{student.name}</p>
                        <p className="text-xs text-gray-600">Class {student.class_level}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-[#1E90FF] text-sm">{student.total_points}</p>
                        <p className="text-xs text-gray-600">points</p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-4">
                  <Users className="mx-auto text-gray-300 mb-2" size={32} />
                  <p className="text-gray-600 text-sm">No rankings available yet</p>
                </div>
              )}
            </div>

            {/* Study Streak */}
            <div className="bg-gradient-to-br from-orange-50 to-red-50 rounded-2xl p-6">
              <div className="flex items-center space-x-3 mb-4">
                <Flame className="text-orange-500" size={32} />
                <div>
                  <h2 className="text-xl font-bold text-gray-800">Study Streak</h2>
                  <p className="text-sm text-gray-600">Keep the momentum going!</p>
                </div>
              </div>
              
              <div className="text-center">
                <div className="text-3xl font-bold text-orange-500 mb-2">
                  {userProfile?.streak_days || 0}
                </div>
                <p className="text-gray-600 text-sm mb-4">days in a row</p>
                
                {(userProfile?.streak_days || 0) > 0 && (
                  <div className="bg-white rounded-lg p-3">
                    <p className="text-xs text-gray-600 mb-1">Next milestone</p>
                    <div className="flex items-center space-x-2">
                      <div className="flex-1 bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-orange-500 h-2 rounded-full transition-all"
                          style={{ width: `${Math.min(((userProfile?.streak_days || 0) % 7) / 7 * 100, 100)}%` }}
                        ></div>
                      </div>
                      <span className="text-xs text-gray-600">7 days</span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;