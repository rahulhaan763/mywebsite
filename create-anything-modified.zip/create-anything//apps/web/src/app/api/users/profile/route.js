import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET() {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = session.user.id;
    
    // Get user profile from both auth_users and users tables
    const authUserRows = await sql`
      SELECT id, name, email, image 
      FROM auth_users 
      WHERE id = ${userId} 
      LIMIT 1
    `;
    
    const userRows = await sql`
      SELECT class_level, total_points, streak_days, last_activity_date, created_at
      FROM users 
      WHERE email = ${session.user.email} 
      LIMIT 1
    `;

    const authUser = authUserRows?.[0] || null;
    const userProfile = userRows?.[0] || null;

    if (!authUser) {
      return Response.json({ error: "User not found" }, { status: 404 });
    }

    const user = {
      ...authUser,
      ...userProfile
    };

    return Response.json({ user });
  } catch (err) {
    console.error("GET /api/users/profile error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function PUT(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { class_level } = body || {};

    if (!class_level || class_level < 8 || class_level > 12) {
      return Response.json(
        { error: "Valid class level (8-12) is required" },
        { status: 400 }
      );
    }

    // Check if user already exists in users table
    const existingUser = await sql`
      SELECT id FROM users WHERE email = ${session.user.email} LIMIT 1
    `;

    if (existingUser.length > 0) {
      // Update existing user
      const result = await sql`
        UPDATE users 
        SET class_level = ${class_level}, updated_at = CURRENT_TIMESTAMP
        WHERE email = ${session.user.email}
        RETURNING id, email, name, class_level, total_points, streak_days, last_activity_date, created_at
      `;
      return Response.json({ user: result[0] });
    } else {
      // Create new user profile
      const result = await sql`
        INSERT INTO users (email, name, class_level)
        VALUES (${session.user.email}, ${session.user.name}, ${class_level})
        RETURNING id, email, name, class_level, total_points, streak_days, last_activity_date, created_at
      `;
      return Response.json({ user: result[0] });
    }
  } catch (err) {
    console.error("PUT /api/users/profile error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}