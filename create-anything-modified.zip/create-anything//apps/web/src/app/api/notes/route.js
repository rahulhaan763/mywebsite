import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.email) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Get user ID from users table
    const userRows = await sql`
      SELECT id FROM users WHERE email = ${session.user.email} LIMIT 1
    `;

    if (userRows.length === 0) {
      return Response.json({ notes: [] });
    }

    const userId = userRows[0].id;
    const url = new URL(request.url);
    const limit = parseInt(url.searchParams.get('limit')) || 20;
    const subject = url.searchParams.get('subject');
    const classLevel = url.searchParams.get('class');

    let query = `
      SELECT 
        id, 
        title, 
        subject, 
        class_level, 
        file_url, 
        file_type, 
        created_at
      FROM notes 
      WHERE user_id = $1
    `;
    
    const params = [userId];
    let paramIndex = 2;

    if (subject) {
      query += ` AND subject = $${paramIndex}`;
      params.push(subject);
      paramIndex++;
    }

    if (classLevel) {
      query += ` AND class_level = $${paramIndex}`;
      params.push(parseInt(classLevel));
      paramIndex++;
    }

    query += ` ORDER BY created_at DESC LIMIT $${paramIndex}`;
    params.push(limit);

    const notes = await sql(query, params);

    return Response.json({ notes });
  } catch (err) {
    console.error("GET /api/notes error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.email) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Get user ID from users table
    const userRows = await sql`
      SELECT id FROM users WHERE email = ${session.user.email} LIMIT 1
    `;

    if (userRows.length === 0) {
      return Response.json({ error: "User profile not found" }, { status: 404 });
    }

    const userId = userRows[0].id;
    const body = await request.json();
    const { title, subject, class_level, original_content, file_url, file_type } = body;

    if (!title || !subject || !class_level) {
      return Response.json(
        { error: "Title, subject, and class level are required" },
        { status: 400 }
      );
    }

    if (class_level < 8 || class_level > 12) {
      return Response.json(
        { error: "Class level must be between 8 and 12" },
        { status: 400 }
      );
    }

    // Create the note
    const result = await sql`
      INSERT INTO notes (user_id, title, subject, class_level, original_content, file_url, file_type)
      VALUES (${userId}, ${title}, ${subject}, ${class_level}, ${original_content || null}, ${file_url || null}, ${file_type || null})
      RETURNING id, title, subject, class_level, file_url, file_type, created_at
    `;

    const note = result[0];

    // Award points for uploading a note (10 points)
    await sql`
      UPDATE users 
      SET total_points = total_points + 10,
          last_activity_date = CURRENT_DATE
      WHERE id = ${userId}
    `;

    return Response.json({ note, points_earned: 10 });
  } catch (err) {
    console.error("POST /api/notes error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}