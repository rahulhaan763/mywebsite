import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET() {
  try {
    const session = await auth();
    if (!session || !session.user?.email) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Get user ID from users table
    const userRows = await sql`
      SELECT id FROM users WHERE email = ${session.user.email} LIMIT 1
    `;

    if (userRows.length === 0) {
      return Response.json({
        total_notes: 0,
        total_summaries: 0,
        total_mind_maps: 0,
        total_quizzes: 0,
        total_quiz_attempts: 0,
        average_score: 0
      });
    }

    const userId = userRows[0].id;

    // Get comprehensive stats
    const [notesCount, summariesCount, mindMapsCount, quizzesCount, quizAttemptsStats] = await sql.transaction([
      sql`SELECT COUNT(*) as count FROM notes WHERE user_id = ${userId}`,
      sql`SELECT COUNT(*) as count FROM summaries WHERE user_id = ${userId}`,
      sql`SELECT COUNT(*) as count FROM mind_maps WHERE user_id = ${userId}`,
      sql`SELECT COUNT(*) as count FROM quizzes WHERE user_id = ${userId}`,
      sql`
        SELECT 
          COUNT(*) as total_attempts,
          AVG(CASE WHEN total_questions > 0 THEN (score::FLOAT / total_questions * 100) ELSE 0 END) as avg_score,
          SUM(points_earned) as total_points_from_quizzes
        FROM quiz_attempts 
        WHERE user_id = ${userId}
      `
    ]);

    const stats = {
      total_notes: parseInt(notesCount[0].count),
      total_summaries: parseInt(summariesCount[0].count),
      total_mind_maps: parseInt(mindMapsCount[0].count),
      total_quizzes: parseInt(quizzesCount[0].count),
      total_quiz_attempts: parseInt(quizAttemptsStats[0].total_attempts || 0),
      average_score: Math.round(parseFloat(quizAttemptsStats[0].avg_score || 0)),
      total_points_from_quizzes: parseInt(quizAttemptsStats[0].total_points_from_quizzes || 0)
    };

    return Response.json(stats);
  } catch (err) {
    console.error("GET /api/users/stats error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}