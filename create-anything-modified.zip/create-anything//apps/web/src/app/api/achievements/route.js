import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET() {
  try {
    const session = await auth();
    if (!session || !session.user?.email) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Get user ID from users table
    const userRows = await sql`
      SELECT id, total_points FROM users WHERE email = ${session.user.email} LIMIT 1
    `;

    if (userRows.length === 0) {
      // Return all achievements as unearned for new users
      const allAchievements = await sql`
        SELECT id, name, description, icon, points_required, badge_color
        FROM achievements
        ORDER BY points_required ASC
      `;

      const achievementsWithStatus = allAchievements.map(achievement => ({
        ...achievement,
        earned: false,
        earned_at: null
      }));

      return Response.json({ achievements: achievementsWithStatus });
    }

    const userId = userRows[0].id;
    const userPoints = userRows[0].total_points || 0;

    // Get all achievements with user's earned status
    const achievements = await sql`
      SELECT 
        a.id,
        a.name,
        a.description,
        a.icon,
        a.points_required,
        a.badge_color,
        ua.earned_at,
        CASE WHEN ua.id IS NOT NULL THEN true ELSE false END as earned
      FROM achievements a
      LEFT JOIN user_achievements ua ON a.id = ua.achievement_id AND ua.user_id = ${userId}
      ORDER BY a.points_required ASC
    `;

    return Response.json({ achievements });
  } catch (err) {
    console.error("GET /api/achievements error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

// Function to check and award achievements
export async function checkAndAwardAchievements(userId, userStats) {
  try {
    // Get user's current achievements
    const userAchievements = await sql`
      SELECT achievement_id FROM user_achievements WHERE user_id = ${userId}
    `;
    
    const earnedAchievementIds = userAchievements.map(ua => ua.achievement_id);

    // Get all achievements
    const allAchievements = await sql`
      SELECT id, name, points_required FROM achievements
    `;

    const newAchievements = [];

    for (const achievement of allAchievements) {
      if (earnedAchievementIds.includes(achievement.id)) {
        continue; // Already earned
      }

      let shouldAward = false;

      // Check achievement criteria
      switch (achievement.name) {
        case 'First Steps':
          shouldAward = userStats.total_notes >= 1;
          break;
        case 'Quiz Master':
          shouldAward = userStats.total_quiz_attempts >= 5;
          break;
        case 'Mind Mapper':
          shouldAward = userStats.total_mind_maps >= 1;
          break;
        case 'Streak Starter':
          shouldAward = userStats.streak_days >= 3;
          break;
        case 'Knowledge Seeker':
          shouldAward = userStats.total_summaries >= 10;
          break;
        case 'Perfect Score':
          // Check if user has any 100% quiz scores
          const perfectScores = await sql`
            SELECT COUNT(*) as count 
            FROM quiz_attempts 
            WHERE user_id = ${userId} AND score = total_questions AND total_questions > 0
          `;
          shouldAward = parseInt(perfectScores[0].count) > 0;
          break;
        case 'Study Champion':
          shouldAward = userStats.total_points >= 500;
          break;
        case 'Consistent Learner':
          shouldAward = userStats.streak_days >= 7;
          break;
        case 'Subject Expert':
          // Check if user has 20+ quizzes in any single subject
          const subjectQuizzes = await sql`
            SELECT subject, COUNT(*) as count
            FROM quiz_attempts qa
            JOIN quizzes q ON qa.quiz_id = q.id
            WHERE qa.user_id = ${userId}
            GROUP BY subject
            HAVING COUNT(*) >= 20
            LIMIT 1
          `;
          shouldAward = subjectQuizzes.length > 0;
          break;
        case 'Learning Legend':
          shouldAward = userStats.total_points >= 1000;
          break;
        default:
          // For point-based achievements
          shouldAward = userStats.total_points >= achievement.points_required;
      }

      if (shouldAward) {
        // Award the achievement
        await sql`
          INSERT INTO user_achievements (user_id, achievement_id)
          VALUES (${userId}, ${achievement.id})
          ON CONFLICT (user_id, achievement_id) DO NOTHING
        `;
        newAchievements.push(achievement);
      }
    }

    return newAchievements;
  } catch (err) {
    console.error("Error checking achievements:", err);
    return [];
  }
}