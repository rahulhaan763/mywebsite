import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.email) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const url = new URL(request.url);
    const limit = parseInt(url.searchParams.get('limit')) || 50;
    const classLevel = url.searchParams.get('class');

    let query = `
      SELECT 
        u.id,
        u.name,
        u.class_level,
        u.total_points,
        u.streak_days,
        u.profile_image,
        COUNT(qa.id) as total_quizzes_taken,
        AVG(CASE WHEN qa.total_questions > 0 THEN (qa.score::FLOAT / qa.total_questions * 100) ELSE 0 END) as avg_score
      FROM users u
      LEFT JOIN quiz_attempts qa ON u.id = qa.user_id
    `;

    const params = [];
    let paramIndex = 1;

    if (classLevel) {
      query += ` WHERE u.class_level = $${paramIndex}`;
      params.push(parseInt(classLevel));
      paramIndex++;
    }

    query += `
      GROUP BY u.id, u.name, u.class_level, u.total_points, u.streak_days, u.profile_image
      ORDER BY u.total_points DESC, u.streak_days DESC
      LIMIT $${paramIndex}
    `;
    params.push(limit);

    const leaderboard = await sql(query, params);

    // Add rank to each user
    const leaderboardWithRank = leaderboard.map((user, index) => ({
      ...user,
      rank: index + 1,
      avg_score: Math.round(parseFloat(user.avg_score || 0))
    }));

    return Response.json({ leaderboard: leaderboardWithRank });
  } catch (err) {
    console.error("GET /api/leaderboard error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}