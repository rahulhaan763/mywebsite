import useAuth from "@/utils/useAuth";
import { BookOpen, LogOut } from "lucide-react";

function MainComponent() {
  const { signOut } = useAuth();
  
  const handleSignOut = async () => {
    await signOut({
      callbackUrl: "/",
      redirect: true,
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 via-blue-50 to-indigo-100 font-nunito flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl p-8 w-full max-w-md text-center">
        <div className="flex items-center justify-center mb-6">
          <BookOpen size={32} className="mr-2 text-[#1E90FF]" />
          <h1 className="text-2xl font-bold text-gray-800">EDUSNAP</h1>
        </div>
        
        <div className="mb-8">
          <LogOut size={48} className="mx-auto text-gray-400 mb-4" />
          <h2 className="text-xl font-bold text-gray-800 mb-2">Sign Out</h2>
          <p className="text-gray-600">Are you sure you want to sign out of your account?</p>
        </div>

        <button
          onClick={handleSignOut}
          className="w-full bg-[#1E90FF] text-white py-3 px-4 rounded-lg font-medium hover:bg-[#0066CC] focus:ring-2 focus:ring-[#1E90FF] focus:ring-offset-2 transition-all"
        >
          Sign Out
        </button>
        
        <div className="mt-4">
          <a
            href="/dashboard"
            className="text-[#1E90FF] hover:text-[#0066CC] font-medium"
          >
            Cancel
          </a>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;