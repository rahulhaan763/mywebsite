import { useState, useEffect } from "react";
import useUser from "@/utils/useUser";
import { BookOpen, User, Trophy, Target } from "lucide-react";

function MainComponent() {
  const { data: user, loading: userLoading } = useUser();
  const [loading, setLoading] = useState(false);
  const [classLevel, setClassLevel] = useState("");
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    // Load pending class level from localStorage
    if (typeof window !== "undefined") {
      const pendingClassLevel = localStorage.getItem("pendingClassLevel");
      if (pendingClassLevel && !classLevel) {
        setClassLevel(pendingClassLevel);
      }
    }
  }, [classLevel]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    if (!classLevel) {
      setError("Please select your class level");
      setLoading(false);
      return;
    }

    try {
      const response = await fetch("/api/users/profile", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ class_level: parseInt(classLevel) }),
      });

      if (!response.ok) {
        throw new Error("Failed to update profile");
      }

      // Clear localStorage
      if (typeof window !== "undefined") {
        localStorage.removeItem("pendingClassLevel");
      }

      setSuccess(true);
      
      // Redirect to dashboard after a short delay
      setTimeout(() => {
        window.location.href = "/dashboard";
      }, 2000);
    } catch (err) {
      setError("Failed to complete setup. Please try again.");
      setLoading(false);
    }
  };

  if (userLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-sky-50 via-blue-50 to-indigo-100 font-nunito flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#1E90FF] mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (success) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-sky-50 via-blue-50 to-indigo-100 font-nunito flex items-center justify-center">
        <div className="bg-white rounded-2xl shadow-xl p-8 w-full max-w-md text-center">
          <div className="flex items-center justify-center mb-6">
            <BookOpen size={32} className="mr-2 text-[#1E90FF]" />
            <h1 className="text-2xl font-bold text-gray-800">EDUSNAP</h1>
          </div>
          
          <div className="mb-8">
            <Trophy size={48} className="mx-auto text-green-500 mb-4" />
            <h2 className="text-xl font-bold text-gray-800 mb-2">Welcome to EDUSNAP!</h2>
            <p className="text-gray-600">Your account has been set up successfully. Redirecting to dashboard...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 via-blue-50 to-indigo-100 font-nunito">
      <div className="flex min-h-screen items-center justify-center p-8">
        <div className="w-full max-w-2xl">
          <div className="text-center mb-8">
            <div className="flex items-center justify-center mb-4">
              <BookOpen size={32} className="mr-2 text-[#1E90FF]" />
              <h1 className="text-2xl font-bold text-gray-800">EDUSNAP</h1>
            </div>
            <p className="text-gray-600">Smart Study Simplified</p>
          </div>

          <div className="bg-white rounded-2xl shadow-xl p-8">
            <div className="text-center mb-8">
              <User size={48} className="mx-auto text-[#1E90FF] mb-4" />
              <h2 className="text-2xl font-bold text-gray-800 mb-2">
                Complete Your Profile
              </h2>
              <p className="text-gray-600">
                Welcome {user?.name}! Let's finish setting up your account.
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Class Level
                </label>
                <select
                  value={classLevel}
                  onChange={(e) => setClassLevel(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#1E90FF] focus:border-transparent outline-none transition-all"
                  required
                >
                  <option value="">Select your class</option>
                  <option value="8">Class 8th</option>
                  <option value="9">Class 9th</option>
                  <option value="10">Class 10th</option>
                  <option value="11">Class 11th</option>
                  <option value="12">Class 12th</option>
                </select>
              </div>

              {error && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-sm text-red-600">
                  {error}
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-[#1E90FF] text-white py-3 px-4 rounded-lg font-medium hover:bg-[#0066CC] focus:ring-2 focus:ring-[#1E90FF] focus:ring-offset-2 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? "Setting up..." : "Complete Setup"}
              </button>
            </form>

            <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center p-4 bg-blue-50 rounded-lg">
                <Target className="mx-auto text-[#1E90FF] mb-2" size={24} />
                <h3 className="font-semibold text-gray-800 text-sm">AI Summaries</h3>
                <p className="text-xs text-gray-600">Convert long notes into quick summaries</p>
              </div>
              <div className="text-center p-4 bg-purple-50 rounded-lg">
                <BookOpen className="mx-auto text-purple-600 mb-2" size={24} />
                <h3 className="font-semibold text-gray-800 text-sm">Mind Maps</h3>
                <p className="text-xs text-gray-600">Visualize concepts with interactive maps</p>
              </div>
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <Trophy className="mx-auto text-green-600 mb-2" size={24} />
                <h3 className="font-semibold text-gray-800 text-sm">Gamification</h3>
                <p className="text-xs text-gray-600">Earn points and unlock achievements</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;